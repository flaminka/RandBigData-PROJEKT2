library(testthat)
library(ClockworkOranges)

test_check("ClockworkOranges")
