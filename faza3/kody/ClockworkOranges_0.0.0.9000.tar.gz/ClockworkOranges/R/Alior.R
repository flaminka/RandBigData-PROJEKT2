#' Przyk�adowe posty z facebookowego profilu Alior banku
#' 
#' Zbi�r zwiera nast�puj�ce kolumny:
#' \itemize{
#'  \item X. zmienna tekstowa
#'  \item id. id posta
#'  \item parent_id. id posta nadrz�dnego
#'  \item created_at. data utworzenia posta 
#'  \item threat_id. numer w�tku
#'  \item subject. temat rozmowy
#'  \item user_name. nazwa u�ytkownika pisz�cego post
#'  \item user_link. link do profilu autora postu
#'  \item source. link do profilu alior banku
#'  \item body. tre�� postu
#'  \item rzeczowniki. rzeczownik wyst�puj�ce w po�cie oddzielone "|"
#' }
#' 
#' @docType data
#' @keywords datasets
#' @name Alior
#' @usage data(Alior)
#' @format ramka danych z 100 wierszami i 11 kolumnami.